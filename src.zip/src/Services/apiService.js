import axios from 'axios';

const API_BASE_URL = 'http://localhost:8081/api';

export const fetchEmployees = () => {
    return axios.get(`${API_BASE_URL}/employees`);
};

export const addEmployee = (employee) => {
    return axios.post(`${API_BASE_URL}/employees`, employee);
};

export const fetchVendors = () => {
    return axios.get(`${API_BASE_URL}/vendors`);
};




export const fetchSentEmail = () => {
    return axios.get(`${API_BASE_URL}/emails`);
};


export const addVendor = (vendor) => {
    return axios.post(`${API_BASE_URL}/vendors`, vendor);
};

export const sendEmailsToVendors = (vendors) => {
    return axios.post(`${API_BASE_URL}/vendors/send-email`, vendors);
};

