// VendorForm.jsx
import React, { useState } from 'react';

function VendorForm({ onAddVendor }) {
    const [vendor, setVendor] = useState({ name: '', email: '', upi: '' });

    const handleChange = (e) => {
        setVendor({ ...vendor, [e.target.name]: e.target.value });
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        onAddVendor(vendor);
        setVendor({ name: '', email: '', upi: '' });
    };

    return (
        <form onSubmit={handleSubmit}>
            <input type="text" name="name" placeholder="Name" value={vendor.name} onChange={handleChange} />
            <input type="email" name="email" placeholder="Email" value={vendor.email} onChange={handleChange} />
            <input type="text" name="upi" placeholder="UPI" value={vendor.upi} onChange={handleChange} />
            <button type="submit">Add Vendor</button>
        </form>
    );
}

export default VendorForm;
