// EmailForm.jsx
import React, { useState } from 'react';

function EmailForm({ vendors, onSendEmails }) {
    const [selectedVendors, setSelectedVendors] = useState([]);

    const handleCheckboxChange = (vendor) => {
        setSelectedVendors((prev) =>
            prev.includes(vendor) ? prev.filter((v) => v !== vendor) : [...prev, vendor]
        );
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        onSendEmails(selectedVendors);
    };

    return (
        <form onSubmit={handleSubmit}>
            {vendors.map((vendor) => (
                <div key={vendor.id}>
                    <input
                        type="checkbox"
                        value={vendor.id}
                        onChange={() => handleCheckboxChange(vendor)}
                    />
                    {vendor.name}
                </div>
            ))}
            <button type="submit">Send Emails</button>
        </form>
    );
}

export default EmailForm;
