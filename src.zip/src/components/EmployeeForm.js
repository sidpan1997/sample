// EmployeeForm.jsx
import React, { useState } from 'react';

function EmployeeForm({ onAddEmployee }) {
    const [employee, setEmployee] = useState({ name: '', designation: '', ctc: '', email: '' });

    const handleChange = (e) => {
        setEmployee({ ...employee, [e.target.name]: e.target.value });
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        onAddEmployee(employee);
        setEmployee({ name: '', designation: '', ctc: '', email: '' });
    };

    return (
        <form onSubmit={handleSubmit}>
            <input type="text" name="name" placeholder="Name" value={employee.name} onChange={handleChange} />
            <input type="text" name="designation" placeholder="Designation" value={employee.designation} onChange={handleChange} />
            <input type="number" name="ctc" placeholder="CTC" value={employee.ctc} onChange={handleChange} />
            <input type="email" name="email" placeholder="Email" value={employee.email} onChange={handleChange} />
            <button type="submit">Add Employee</button>
        </form>
    );
}

export default EmployeeForm;
