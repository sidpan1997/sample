package com.sample.Sample.service;

import com.sample.Sample.entity.Vendor;

import java.util.List;

public interface VendorService {

    Vendor createVendor(Vendor vendor);

    public List<Vendor> getAllVendors();
}
