package com.sample.Sample.controller;

import com.sample.Sample.entity.Email;
import com.sample.Sample.service.EmailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/emails")
public class EmailController {
    @Autowired
    private EmailService emailService;

    @GetMapping
    public List<Email> getAllSentEmails() {
        return emailService.getAllSentEmails();
    }
}
