package com.sample.Sample.controller;

import com.sample.Sample.entity.Vendor;
import com.sample.Sample.service.EmailService;
import com.sample.Sample.service.VendorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/vendors")
public class VendorController {
    @Autowired
    private VendorService vendorService;
    @Autowired
    private EmailService emailService;

    @PostMapping
    public Vendor createVendor(@RequestBody Vendor vendor) {
        return vendorService.createVendor(vendor);
    }

    @GetMapping
    public List<Vendor> getAllVendors() {
        return vendorService.getAllVendors();
    }

    @PostMapping("/send-email")
    public ResponseEntity<Void> sendEmails(@RequestBody List<Vendor> vendors) {


            try {
                for (Vendor vendor1 : vendors)
                emailService.sendEmailToVendor(vendor1);
                return ResponseEntity.ok().build();
            } catch (Exception e) {

                System.err.println("Error sending emails to vendors: " + e.getMessage());
                e.printStackTrace();

                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
            }
        }



}

