package com.sample.Sample.service;

import com.sample.Sample.entity.Email;
import com.sample.Sample.entity.Vendor;

import java.util.List;

public interface EmailService {

    void  sendEmailToVendor(Vendor vendor);

    List<Email> getAllSentEmails();


}
