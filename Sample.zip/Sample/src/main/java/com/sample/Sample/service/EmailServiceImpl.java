package com.sample.Sample.service;

import com.sample.Sample.entity.Email;
import com.sample.Sample.entity.Vendor;
import com.sample.Sample.repository.EmailRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class EmailServiceImpl implements EmailService{

    @Autowired
    private JavaMailSender mailSender;

    @Autowired
    private EmailRepository sentEmailRepository;

    @Value("${spring.mail.username}")
    private String fromEmail;
    @Override
    public void sendEmailToVendor(Vendor vendor) {
        String subject = "Payment Notification";
        String content = String.format("Sending payments to vendor %s at upi %s", vendor.getName(), vendor.getUpi());

        SimpleMailMessage message = new SimpleMailMessage();
        message.setFrom(fromEmail);
        message.setTo(vendor.getEmail());
        message.setSubject(subject);
        message.setText(content);

        mailSender.send(message);

        Email sentEmail = new Email();
        sentEmail.setVendorName(vendor.getName());
        sentEmail.setVendorEmail(vendor.getEmail());
        sentEmail.setVendorUpi(vendor.getUpi());
        sentEmail.setEmailContent(content);
        sentEmail.setSentTime(LocalDateTime.now());
        sentEmailRepository.save(sentEmail);


    }

    @Override
    public List<Email> getAllSentEmails() {
        return sentEmailRepository.findAll();
    }
}
